const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');

mysql2

const mysql = require('mysql2');

// إعداد الاتصال بقاعدة البيانات MySQL
const db = mysql.createConnection({
  host: 'localhost', // اسم الخادم أو العنوان
  user: 'root', // اسم المستخدم
  password: 'password', // كلمة المرور
  database: 'samp_database' // اسم قاعدة البيانات
});

// الاتصال بقاعدة البيانات
db.connect((err) => {
  if (err) {
    console.error('فشل الاتصال بقاعدة البيانات: ', err);
    return;
  }
  console.log('تم الاتصال بقاعدة البيانات!');
});

// إعداد البوت
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

client.once('ready', () => {
  console.log('البوت جاهز!');
});

// دالة لجلب الحسابات من قاعدة البيانات وعرضها في إيمبد
function sendEmbedMessage(channelIdd) {
  db.query('SELECT * FROM players LIMIT 10', (err, results) => {
    if (err) {
      console.error('خطأ في الاستعلام: ', err);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('قائمة الحسابات')
      .setDescription('إحصائيات الحسابات في اللعبة')
      .setTimestamp();

    // إضافة الحسابات إلى الإيمبد
    results.forEach(player => {
      embed.addFields({
        name: `اللاعب: ${player.username}`,
        value: `الرتبة: ${player.rank}\nالمال: ${player.money}`,
        inline: true
      });
    });

    const channel = client.channels.cache.get(channelIdd);
    if (channel) {
      channel.send({ embeds: [embed] });
    } else {
      console.log('القناة غير موجودة!');
    }
  });
}

// تحديد القناة التي سيتم إرسال الرسائل إليها
const channelIdd = 'YOUR_CHANNEL_ID_HERE'; // ضع هنا معرف القناة في Discord

// إرسال الإيمبد كل 10 ثواني
setInterval(() => {
  sendEmbedMessage(channelIdd);
}, 1000); // 1000 ملي ثانية = 1 ثواني

// تسجيل دخول البوت باستخدام التوكن
client.login('YOUR_BOT_TOKEN_HERE'); // ضع هنا توكن البوت
