const mysql = require('mysql2');
const { Client, GatewayIntentBits } = require('discord.js');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'samp_database'
});

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

connection.connect((err) => {
  if (err) {
    console.error('خطأ في الاتصال بقاعدة البيانات: ' + err.stack);
    return;
  }
  console.log('تم الاتصال بقاعدة البيانات بنجاح');
});

client.once('ready', () => {
  console.log('تم تسجيل الدخول إلى Discord بنجاح!');
  setInterval(fetchAndSendPlayerData, 1000);
});

const fetchAndSendPlayerData = () => {
  connection.query('SELECT * FROM user', async (err, results) => {
    if (err) {
      console.error('حدث خطأ في الاستعلام: ' + err.stack);
      return;
    }

    if (results.length > 0) {
      let message = 'n\:Player Panel';
      results.forEach(player => {
        message += `\nName : ${player.name}\nScore : ${player.score}\nCountry : ${player.country}\n`;
      });

      const channel = client.channels.cache.get('YOUR_CHANNEL_ID'); // ضع هنا ID القناة
      if (channel) {
        channel.send(message).then(() => {
          console.log('تم إرسال الرسالة إلى Discord');
        }).catch(err => {
          console.error('حدث خطأ أثناء إرسال الرسالة إلى Discord: ', err);
        });
      } else {
        console.error('القناة غير موجودة!');
      }
    } else {
      console.log('لا يوجد لاعبين في قاعدة البيانات');
    }
  });
}
