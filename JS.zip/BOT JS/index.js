const { 
    Client, 
    GatewayIntentBits, 
    ButtonBuilder, 
    ButtonStyle, 
    ActionRowBuilder,
    EmbedBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionFlagsBits,
    SlashCommandBuilder,
    PermissionsBitField,
    AttachmentBuilder,
    TextChannel,
    GuildMember,
    ComponentType,
    ApplicationCommandType,
    ApplicationCommandOptionType,
    Collection, ActivityType } = require('discord.js');
  
const fs = require('fs');
const axios = require('axios');
const samp = require('samp-query');

const client = new Client({
intents: [
GatewayIntentBits.Guilds,
GatewayIntentBits.GuildMembers,
GatewayIntentBits.GuildBans,
GatewayIntentBits.GuildMessages,
GatewayIntentBits.MessageContent,
],
});

client.setMaxListeners(23333)



const serverIP = '188.165.140.93';
const serverPort = 1315;
const channelId = '1332476279580266536';

let messageToUpdate = null; 

client.on('ready', async () => { 
console.log(`تم تسجيل الدخول باسم: ${client.user.tag}`);


const channel = client.channels.cache.get(channelId);
if (channel) {
try {
const initialEmbed = new EmbedBuilder()
.setTitle(`Libya Country Status`)
.setDescription('جاري التحميل...');

const sentMessage = await channel.send({ embeds: [initialEmbed] });
messageToUpdate = sentMessage; 

updateServerInfo(); 
setInterval(updateServerInfo, 1000);
} catch (error) {
console.error('حدث خطأ أثناء إرسال الرسالة الأولية:', error);
}
} else {
console.error('Channel Not Found');
}
});

async function updateServerInfo() {
if (!messageToUpdate) {
return;
}

try {
samp({ host: serverIP, port: serverPort }, (error, response) => {
const embed = new EmbedBuilder().setTitle(`Libya Country Status`);

if (error) {
embed
.setColor(0xff0000)
.addFields(
{ name: 'STAT', value: '```Offline 🔴```', inline: true },
{ name: 'PLAYERS', value: '```Unknown !```', inline: true },
{ name: 'IP ADDRESS', value: '```Unknown !```', inline: true },
{ name: 'GAMEMOD', value: '```Unknown !```', inline: true },
);
} else {
const online = response.online;
const playerCount = response.online;
const adressipp = ' 188.165.140.93:1315 ';
const gammemodee = response.gamemode;
const languagee = response.mapname
const isServerOnline = Boolean(online);

embed
.setColor(0xff0000)
.addFields(
{ name: 'STATS', value:  'Online 🟢', inline: true },
{ name: 'PLAYERS', value: `${playerCount} / 100`, inline: true },
{ name: 'IP ADDRESS', value: adressipp, inline: true }, 
{ name: 'LANGUAGE', value: `${languagee}`, inline: true },
{ name: 'GAMEMODE', value: `${gammemodee}`, inline: true },
);
}

messageToUpdate.edit({ embeds: [embed] });
});
} catch (error) {
console.error('An error occurred while fetching server information. ', error);
}
}



client.login('MTIyOTExMjkyMzE0NjY4MjM5OA.GsFvvJ.CyG2zBg7ncOssub5Aw1PrxnyYSBHirKEEzct3U'); 
